<!DOCTYPE html>
<html lang="en-US">
	<head>
		<!-- Meta setup -->
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">	
		<!-- Title -->
		<title>Welcome</title>

		<!-- Fav Icon -->
		<link rel="icon" href="images/favicon.ico" />	

		<!-- Include Bootstrap -->
		<link rel="stylesheet" href="css/bootstrap.css" />
		
		<!-- Main StyleSheet -->
		<link rel="stylesheet" href="style.css" />	

	</head>
	<body>		
		<div class="main-wrapper">
			<div class="header-area">
				<h2>PHP / Laravel - Software Development</h2>
			</div>
			<div class="time-area">
				<p>	Date:<?php date_default_timezone_set("asia/dhaka"); echo date("d M Y");?></p>
				<p>Time: <?php date_default_timezone_set("asia/dhaka");echo date("h:mA");?></p>
			</div>
			<div class="body-area">


				






			Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi deserunt nihil quos officiis cumque rem distinctio eos impedit pariatur. Nobis, obcaecati. Impedit hic sed numquam dolorem voluptatem animi veniam officia!











				
			</div>
			<div class="footer-area">
				<p>Copyright &copy; 2021 Asad Kabir</p>
				<h4><a href="http://www.asadkabir.com">www.asadkabir.com</a></h4>
			</div>
		</div>			
		<!-- 
		<script src="js/jquery-3.4.1.min.js"></script>		
		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="https://kit.fontawesome.com/7749c9f08a.js"></script>	
		<script src="js/scripts.js"></script>
		-->		
	</body>
</html>